require 'test/unit'

require_relative "./test_datastructures.rb"
require_relative "./test_operators.rb"
require_relative "./test_managers.rb"

class TestStart < Test::Unit::TestCase
    def test_start
        assert(true)
    end
end